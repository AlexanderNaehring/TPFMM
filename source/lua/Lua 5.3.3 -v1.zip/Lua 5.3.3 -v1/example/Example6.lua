
bee={}
for i=1,1000 do
  bee[i] = sprite.new("Geebee2.bmp",0xff00ff) --transparent background
  bee[i].x = math.random(1,640)
  bee[i].y = math.random(1,400)
  bee[i].visible = 255
end

pb=sprite.new("PureBasic.bmp")
pb.x=320
pb.y=200
pb.visible=255
pb=nil

--orbit= sprite.new("world.png")
orbit= sprite.new("background.bmp")
orbit.visible=255
orbit.x = math.random(1,640)
orbit.y = math.random(1,400)
dx=1
dy=1

function timer (a,b)
  local bee
  --bee = sprite.new("Geebee2.bmp",0xff00ff) --transparent background
  --bee.x = math.random(1,640)
  --bee.y = math.random(1,400)
  --bee.visible = 255
  orbit.x=orbit.x+dx
  orbit.y=orbit.y+dy
  if orbit.x <0 then orbit.x=0; dx=1 end
  if orbit.y <0 then orbit.y=0; dy=1 end
  if orbit.x >640 then orbit.x=640; dx=-1 ; end
  if orbit.y >400 then orbit.y=400; dy=-1 ; end
  --bee:dispose()
end