print "Start"

a = vec3.new(1.5, 2.1, 3.3)
print "1"
b = vec3.new(23, 5 ,17)
print "2"
c = a + b
print "3"

print " ----"

print(a)
print("+")
print(b)
print("=")
print(vec3.str(c))
print "--------------"
print (a.x .. "/" .. a.y .. "/" .. a.z .."  ".. a.str)
a.x=200
a.y=300
a.z=400
print(a .. "b")
print("b"..a)
print "weiter"

