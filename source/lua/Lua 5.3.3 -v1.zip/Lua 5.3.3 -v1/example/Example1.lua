print ("Output over pure basic debug")

function add (a,b)
  return a+b
end