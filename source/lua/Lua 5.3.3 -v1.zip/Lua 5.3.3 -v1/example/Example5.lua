﻿;
; Zugriff auf die Standard-Bibliotheken unterbinden
; mittels den bibliotheken io und os hat man mehr oder minder Zugriff auf alles - sollte man also lieber ersetzen.
; Auch werden hier mehrere Quelldateien geladen, die nacheinander in der gleichen Umgebung aufgerufen werden.


XIncludeFile "..\module_lua.pbi"
UseModule lua

CompilerIf #PB_Compiler_Processor=#PB_Processor_x86
  Debug "32BIT-Test"
  Debug "PB:"+#PB_Compiler_Version
CompilerEndIf

ProcedureC MyPrint(*L)
  ;Debug "print:"+ *l
  Protected i.i
  Protected max=lua_gettop(*L)
  ;Debug "myprint_max:"+max
  Protected res.s=""
  For i=1 To max
    If lua_isstring(*l,i)
      res+ lua_tostring(*L, i)
    ElseIf luaL_callmeta(*l,i,"__tostring")
      res+lua_tostring(*l,-1)    
    EndIf    
  Next
  Debug "Print | "+res
  ProcedureReturn 0
EndProcedure

Procedure LUA_KillGlobalTable(lua,table.s)
  lua_getglobal(Lua, table)
  lua_pushnil(lua)
  While (lua_next(lua,-2) <>0 )
    ;Debug "1"+lua_typename(lua,lua_type(lua,-2))+" "+lua_tostring(lua,-2)
    ;Debug "  2"+lua_typename(lua,lua_type(lua,-1))+" "+lua_tostring(lua,-1)  
    lua_pop(lua,1); remove "value"-part
    lua_pushnil(Lua); nil
                    ;lua_pushcfunction(Lua, @myprint())
    lua_setfield(Lua, -3, lua_tostring(lua,-2));
  Wend
  lua_pop(lua,1)
EndProcedure

;load a buffer and the chunk-adress to a table __pb_chunklist
Procedure LoadBuffer(lua,start,size,name.s)
  Protected res
  Protected type
  
  If lua_getglobal(Lua, "__pb_chunklist")= #LUA_TNIL
    lua_newtable (lua)
    lua_pushvalue(lua,-1)
    lua_setglobal(Lua, "__pb_chunklist");
  EndIf
  
  res=luaL_loadbuffer(lua,start,size,name)
  If res
    Debug "Lua Error|" + lua_tostring(LUA, -1)
    lua_pop(LUA, 1)
    lua_pushnil(lua)
  EndIf
  lua_setfield(lua,-2,name)
  lua_pop(lua,1)
  ProcedureReturn res
EndProcedure

;call a chunk from the __pb_chunklist
Procedure CallChunk(lua,name.s)
  Protected res
  Debug ~"\ncall:"+name
  lua_getglobal(Lua, "__pb_chunklist")
  lua_getfield(Lua, -1, name);get chunk
  lua_remove(Lua, -2);remove table from stack
  
  res= lua_pcall(LUA, 0, #LUA_MULTRET, 0);IMPORTANT remove the last 0!
  If res
    Debug "Lua Error|" + lua_tostring(LUA, -1)
    lua_pop(LUA, 1)    
  EndIf
EndProcedure


If Lua_Initialize("..\")=#False
  End
EndIf

;Debug PeekS(?headerfile,-1,#PB_Ascii)
;Debug PeekS(?mainfile,-1,#PB_Ascii)


;übliches öffnen und aktivieren
lua=luaL_newstate()
luaL_openlibs(LUA)
lua_register(LUA, "print", @MyPrint())

; Remove os.execute
lua_getglobal(Lua, "os")
lua_pushnil(Lua); or lua_pushcfunction(Lua, @myprint()) to replace the routine with a own routine
lua_setfield(Lua, -2, "execute");
lua_pop(Lua, 1)                 ;

; Remove complete table 
LUA_KillGlobalTable(lua,"os")

;replace execute with myprint-function
lua_getglobal(Lua, "os")
lua_pushcfunction(Lua, @myprint())
lua_setfield(Lua, -2, "execute");
lua_pop(Lua, 1)                 ;

LoadBuffer(lua,?headerfile,?end_headerfile-?headerfile-1,"header")
loadbuffer(lua,?mainfile,?end_mainfile-?mainfile-1,"main")
loadbuffer(lua,?tailfile,?end_tailfile-?tailfile-1,"tail")

CallChunk(lua,"header")

CallChunk(lua,"main")
CallChunk(lua,"tail")
CallChunk(lua,"main")
CallChunk(lua,"tail")

Lua_close(lua)

Lua_Dispose()

DataSection
  headerfile:
  Data.b ~"for key,value in pairs(_G) do \n print (key ,\" -- \",value) \n end \n print \"header\" \n aaa=102 "
  ;Data.b ~"print \"header\" \n aaa=102 "
  end_headerfile:
  
  mainfile:
  Data.b ~"os = require('os') \n os.execute \"c:\\\\windows\\\\system32\\\\cmd.exe\";print(\"main\".. aaa); aaa=103 "
  ;Data.b ~"print(\"main\".. aaa); aaa=103 "
  end_mainfile:
  
  tailfile:
  Data.b ~"print (\"tail\" ..aaa)\naaa=104 "
  end_tailfile:
  
EndDataSection


;string -- 
;collectgarbage -- This function is a generic interface to the garbage collector. 
;coroutine -- This library comprises the operations to manipulate coroutines, which come inside the table coroutine. 
;tonumber -- When called with no base, tonumber tries to convert its argument to a number.
;getmetatable -- returns the metatable of the given object. 
;require --** Loads the given module.
;bit32 -- The bit32 library has been deprecated
;tostring -- Receives a value of any type and converts it to a string in a human-readable format.
;dofile -- Opens the named file and executes its contents as a Lua chunk.
;table -- 
;rawequal -- 
;loadfile -- 
;next -- 
;pairs -- 
;pcall -- 
;rawset -- 
;_G -- 
;package -- 
;type -- 
;math -- 
;utf8 -- 
;debug -- 
;ipairs -- 
;select -- 
;xpcall -- 
;load -- 
;os -- 
;io -- 
;print -- 
;assert -- 
;error -- 
;rawlen -- 
;_VERSION -- Lua 5.3
;setmetatable -- 
;rawget -- 
;header
